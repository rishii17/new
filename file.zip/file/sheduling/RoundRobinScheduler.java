import java.util.LinkedList;
import java.util.Queue;

class Process {
    String name;
    int burstTime;

    public Process(String name, int burstTime) {
        this.name = name;
        this.burstTime = burstTime;
    }
}

public class RoundRobinScheduler {
    public static void main(String[] args) {
        // Create a list of processes
        Process[] processes = {
                new Process("P1", 10),
                new Process("P2", 5),
                new Process("P3", 8),
                new Process("P4", 12)
        };

        // Set time quantum
        int timeQuantum = 2;

        // Execute Round Robin scheduling
        roundRobinScheduling(processes, timeQuantum);
    }

    static void roundRobinScheduling(Process[] processes, int timeQuantum) {
        Queue<Process> queue = new LinkedList<>();

        // Add processes to the queue
        for (Process process : processes) {
            queue.add(process);
        }

        System.out.println("Round Robin Scheduling:");

        // Process until the queue is not empty
        while (!queue.isEmpty()) {
            Process currentProcess = queue.poll();
            System.out.println("Executing process " + currentProcess.name);

            // Reduce burst time by time quantum
            if (currentProcess.burstTime > timeQuantum) {
                currentProcess.burstTime -= timeQuantum;
                System.out.println("Remaining burst time for " + currentProcess.name + ": " + currentProcess.burstTime);
                queue.add(currentProcess);  // Add the process back to the queue
            } else {
                System.out.println(currentProcess.name + " has completed!");
            }
        }
    }
}
