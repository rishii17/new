import java.util.*;

class Process {
    String name;
    int arrivalTime;
    int burstTime;
    int priority;
    int remainingTime;
    int completionTime;
    int waitingTime;
    int turnaroundTime;

    public Process(String name, int arrivalTime, int burstTime, int priority) {
        this.name = name;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.priority = priority;
        this.remainingTime = burstTime;
    }
}

public class PreemptivePriority {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();

        List<Process> processes = new ArrayList<>();

        // Input process details
        for (int i = 0; i < n; i++) {
            System.out.print("Enter name of process " + (i + 1) + ": ");
            String name = scanner.next();
            System.out.print("Enter arrival time of process " + (i + 1) + ": ");
            int arrivalTime = scanner.nextInt();
            System.out.print("Enter burst time of process " + (i + 1) + ": ");
            int burstTime = scanner.nextInt();
            System.out.print("Enter priority of process " + (i + 1) + ": ");
            int priority = scanner.nextInt();

            processes.add(new Process(name, arrivalTime, burstTime, priority));
        }

        // Sort processes based on arrival time
        processes.sort(Comparator.comparingInt(p -> p.arrivalTime));

        // Execute processes using preemptive Priority scheduling
        int currentTime = 0;
        int completedProcesses = 0;
        while (completedProcesses < n) {
            Process selectedProcess = null;
            int highestPriority = Integer.MAX_VALUE;

            for (Process process : processes) {
                if (process.arrivalTime <= currentTime && process.priority < highestPriority && process.remainingTime > 0) {
                    highestPriority = process.priority;
                    selectedProcess = process;
                }
            }

            if (selectedProcess == null) {
                currentTime++;
            } else {
                selectedProcess.remainingTime--;
                currentTime++;

                if (selectedProcess.remainingTime == 0) {
                    selectedProcess.completionTime = currentTime;
                    selectedProcess.turnaroundTime = selectedProcess.completionTime - selectedProcess.arrivalTime;
                    selectedProcess.waitingTime = selectedProcess.turnaroundTime - selectedProcess.burstTime;
                    completedProcesses++;
                }
            }
        }

        // Display results
        System.out.println("\nProcess\tArrival Time\tBurst Time\tPriority\tCompletion Time\tWaiting Time\tTurnaround Time");
        for (Process process : processes) {
            System.out.printf("%s\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n", process.name, process.arrivalTime,
                    process.burstTime, process.priority, process.completionTime, process.waitingTime, process.turnaroundTime);
        }

        // Calculate average waiting time and average turnaround time
        float avgWaitingTime = 0, avgTurnaroundTime = 0;
        for (Process process : processes) {
            avgWaitingTime += process.waitingTime;
            avgTurnaroundTime += process.turnaroundTime;
        }
        avgWaitingTime /= n;
        avgTurnaroundTime /= n;

        System.out.printf("\nAverage Waiting Time: %.2f\n", avgWaitingTime);
        System.out.printf("Average Turnaround Time: %.2f\n", avgTurnaroundTime);

        scanner.close();
    }
}
